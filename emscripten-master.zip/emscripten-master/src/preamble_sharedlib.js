// === Auto-generated preamble library stuff ===

//========================================
// Runtime essentials
//========================================

// === Body ===

