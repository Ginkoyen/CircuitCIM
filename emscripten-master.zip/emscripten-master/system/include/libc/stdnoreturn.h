#ifndef _STDNORETURN_H
#define _STDNORETURN_H
#include <features.h>
#define noreturn _Noreturn
#endif
