These files are from libc++, svn revision 218372, 2014-09-24.
